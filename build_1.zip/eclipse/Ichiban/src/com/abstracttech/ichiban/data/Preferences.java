package com.abstracttech.ichiban.data;

/**
 * this holds global preferences
 */
public class Preferences {
	
	public static boolean vibrate, sound, restartDat;	//All preferences data 
}
