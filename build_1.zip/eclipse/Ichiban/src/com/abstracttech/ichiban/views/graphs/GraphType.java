package com.abstracttech.ichiban.views.graphs;

public enum GraphType {
	PATH,
	SPEED,
	ACCELERATION
}
